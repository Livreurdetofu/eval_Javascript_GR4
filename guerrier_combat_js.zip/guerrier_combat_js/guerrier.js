var health1 = 100;
var health2 = 100;
const precision1=Math.floor(Math.random()*10)
const precision2=Math.floor(Math.random()*10)
console.log("Précision Guerrier 1=", precision1)
console.log("Précision Guerrier 2=", precision2)


if (precision1>precision2) {

  while (health1>=0 & health2>=0){

    var rng1=Math.random()*10
    if (rng1>5) {
    var attaque1 = Math.floor(Math.random()*20)
    console.log("Guerrier1 attaque")
    health2 = health2 -= attaque1
    console.log("Guerrier 2:", health2,"PV")
    }

    else {
      console.log("Guerrier 1 rate son attaque")
    }

    if (health2<=0){
      break
    }
  
    var rng2=Math.random()*10
    if (rng2>5) {
    var attaque2 = Math.floor(Math.random()*20)
    console.log("Guerrier2 attaque")
    health1 = health1 -= attaque2
    console.log("Guerrier 1:", health1,"PV")
    } 
    else {
      console.log("Guerrier 2 rate son attaque")
    }
    
  }
}

else {

  while (health1>=0 & health2>=0){

    var rng2=Math.random()*10
    if (rng2>5) {
    var attaque2 = Math.floor(Math.random()*20)
    console.log("Guerrier2 attaque")

    health1 = health1 -= attaque2
    console.log("Guerrier 1:", health1,"PV")
    }
    else {
      console.log("Guerrier 2 rate son attaque")
    }
    
    if (health1<=0){
      break
    }

    var rng1=Math.random()*10
    if (rng1>5) {
    var attaque1 = Math.floor(Math.random()*20)
    console.log("Guerrier1 attaque")
    health2 = health2 -= attaque1
    console.log("Guerrier 2:", health2,"PV")
    }
    else {
      console.log("Guerrier 1 rate son attaque")
    }
  }
}

if (health1<=0){
  console.log("Guerrier 1 a perdu")
}
else {
  console.log("Guerrier 2 a perdu")
}


