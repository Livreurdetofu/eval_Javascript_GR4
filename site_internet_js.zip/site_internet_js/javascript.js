//Dark & Light button

  //appeler le bouton appelé 'dark-light-button' depuis le HTML
  const darkLightButton = document.getElementById("dark-light-button"); 
  const variantButtonGroup = document.querySelectorAll(".light-mode");


  //changer le background par la version 'light-mode' de la classe '.body' sur un appui simple
  darkLightButton.addEventListener("click", () => {
    document.body.classList.toggle("light-mode");
    variantButtonGroup.forEach(button => {
      button.classList.toggle("light-mode");
    });
  });



// Tab
  //Regroupe tt élément contenant tab-button dans des constantes
  const tabButton = document.querySelectorAll(".tab-button");
  const tabContent = document.querySelectorAll(".tab-content");

  //itération sur chaque onglet
  tabButton.forEach(button => {
      button.addEventListener("click", () => {
        const targetTab = button.getAttribute("data-tab");  //Permet de lier l'onglet à son conteneur correspondant via l'id

        //Retire l'attribut "active" de tous les onglets/conteneurs
        tabButton.forEach(button => button.classList.remove("active"));
        tabContent.forEach(content => content.classList.remove("active"));

        //Ajoute l'attribut "active" à l'onglet/conteneur selectionnés pour l'afficher
        button.classList.add("active");
        document.getElementById(targetTab).classList.add("active");
       });
  });



//Formulaire
let form=document.querySelector('form')
form.addEventListener('submit', function(event){
  event.preventDefault();               //Empeche la page de se recharger apres appui sur 'submit'
  
  //id
  let id=document.querySelector('#id')
  let idError = document.querySelector('#id-error');
  if (id.value.length<6){                                   //Mini. 6 caractères pour le pseudo
    idError.textContent = "must be at least 6 caracters";   //Message d'erreur
    id.classList.add('error')                               //Couleur rouge pour les champs incorrects
    
  } else {
    idError.textContent = "";                               //Retire le message d'erreur
    id.classList.remove('error')
    id.classList.add('success')
  };

  //Email
  let email=document.querySelector('#email')
  let emailError = document.querySelector('#email-error');
  if (email.value=='' || !email.value.includes(".")){ 
    emailError.textContent = "must contain a '@' and a '.'";
    email.classList.add('error')
  } else {
    emailError.textContent = "";
    email.classList.remove("error")     //Retire la class 'error' afin que le vert s'affiche correctement
    email.classList.add('success')
  };

  //password
  let passwordError = document.querySelector('#password-error');
  let passCheck= new RegExp(
    "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[-+_!@#$%^&*.,?])"     
  );
  if (password.value.length<8 || passCheck.test(password.value)==false){      //Mini 8 caractères et doit répondre aux prérequis du RegExp
    password.classList.add('error')
    passwordError.textContent = "must contain an upperscale, a lowerscale, a number and a special character";
  } else {
    passwordError.textContent = "";      
    password.classList.remove('error')
    password.classList.add('success')
  }

  //confirm password
  let confirmPasswordError = document.querySelector('#confirm-password-error');
  let confirmPassword=document.querySelector('#password2')
  let password1=document.querySelector('#password').value;    //contenu du mot de passe 1 
  let password2=document.querySelector('#password2').value;   //contenu du mot de passe 2 pour comparaison
  if (password1 !== password2){
    confirmPasswordError.textContent = "must match the previous password";
    confirmPassword.classList.add('error')
  } else {
    confirmPasswordError.textContent = "";
    confirmPassword.classList.remove('error')
    confirmPassword.classList.add('success')
    }

  //Overall
  let formularSend=document.getElementById('formular-sent')
  if (id.classList.contains('success') && 
      email.classList.contains('success') && 
      password.classList.contains('success') && 
      confirmPassword.classList.contains('success')){
        formularSend.textContent="Formular Sent!"
      }

      
})


